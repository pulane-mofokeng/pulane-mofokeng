﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _36002887_Prac10_Mofokeng
{
    public partial class PaymentForm : Form
    {
        public PaymentForm(double totalCost)
        {
            InitializeComponent();
            lblTotal.Text = $"R{totalCost:F2}";
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
