﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _36002887_Prac10_Mofokeng
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void BookingInfo()
        {
            lstBooking.Items.Clear();

            string name = txtName.Text;
            string surname = txtSurname.Text;
            string package = cmbPackage.Text;
            int days = 1;

            lstBooking.Items.Add($"{name} {surname}");
            lstBooking.Items.Add($"{package}");

            if (package == "Daily Fitness Session")
            {
                lstBooking.Items.Add($"Number of days: 1");
                lstBooking.Items.Add($"Cost: R120.00");
            }
            else if (package == "Spa and Wellness Retreat")
            {
                if(int.TryParse(txtDays.Text, out days))
                {
                    lstBooking.Items.Add($"Number of days: {days}");

                    double total = 0.0;
                    double cost = 400.00;

                    for (int i = 1; i <= days; i++)
                    {
                        lstBooking.Items.Add($"Day {i}: R{cost:F2}");
                        total += cost;
                        cost -= cost * 0.07;
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number of days");
                }
            }
        }
        private double TotalCost(int days)
        {
            double total = 0;
            double cost = 400;
            
            for(int i = 1; i <= days; i++)
            {
                total += cost;
                cost -= cost * 0.07;
            }
            return total;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtSurname.Text = "";
            cmbPackage.SelectedIndex = -1;
            txtDays.Text = "";
            lstBooking.Items.Clear();
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            if (cmbPackage.Text == "Spa and Wellness Retreat")
            {
                if (int.TryParse(txtDays.Text, out int days))
                {
                    double totalAmount = TotalCost(days);

                    PaymentForm payform = new PaymentForm(totalAmount);
                    payform.ShowDialog();
                }
            }
            else
            {
                PaymentForm payform = new PaymentForm(120);
                payform.ShowDialog();
            }
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookingInfo();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbPackage.Items.Add("Daily Fitness Session");
            cmbPackage.Items.Add("Spa and Wellness Retreat");
        }
    }
}
