﻿namespace Prac6_Books36002887
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rbtn1stYear = new System.Windows.Forms.RadioButton();
            this.rbtn2ndYear = new System.Windows.Forms.RadioButton();
            this.btnTotalCost = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.rbtn3rdYear = new System.Windows.Forms.RadioButton();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.grpModules = new System.Windows.Forms.GroupBox();
            this.chkCSharp = new System.Windows.Forms.CheckBox();
            this.chkCPlus = new System.Windows.Forms.CheckBox();
            this.chkVisualBasic = new System.Windows.Forms.CheckBox();
            this.chkJava = new System.Windows.Forms.CheckBox();
            this.chkDatabase = new System.Windows.Forms.CheckBox();
            this.grpModules.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(124, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(124, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Level of Study:";
            // 
            // rbtn1stYear
            // 
            this.rbtn1stYear.AutoSize = true;
            this.rbtn1stYear.Location = new System.Drawing.Point(278, 182);
            this.rbtn1stYear.Name = "rbtn1stYear";
            this.rbtn1stYear.Size = new System.Drawing.Size(77, 20);
            this.rbtn1stYear.TabIndex = 3;
            this.rbtn1stYear.TabStop = true;
            this.rbtn1stYear.Text = "1st Year";
            this.rbtn1stYear.UseVisualStyleBackColor = true;
            // 
            // rbtn2ndYear
            // 
            this.rbtn2ndYear.AutoSize = true;
            this.rbtn2ndYear.Location = new System.Drawing.Point(423, 182);
            this.rbtn2ndYear.Name = "rbtn2ndYear";
            this.rbtn2ndYear.Size = new System.Drawing.Size(82, 20);
            this.rbtn2ndYear.TabIndex = 4;
            this.rbtn2ndYear.TabStop = true;
            this.rbtn2ndYear.Text = "2nd Year";
            this.rbtn2ndYear.UseVisualStyleBackColor = true;
            // 
            // btnTotalCost
            // 
            this.btnTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalCost.Location = new System.Drawing.Point(103, 466);
            this.btnTotalCost.Name = "btnTotalCost";
            this.btnTotalCost.Size = new System.Drawing.Size(129, 41);
            this.btnTotalCost.TabIndex = 5;
            this.btnTotalCost.Text = "Total Cost";
            this.btnTotalCost.UseVisualStyleBackColor = true;
            this.btnTotalCost.Click += new System.EventHandler(this.btnTotalCost_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(522, 466);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(144, 41);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(854, 466);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 41);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.PaleGreen;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(457, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(370, 34);
            this.label4.TabIndex = 8;
            this.label4.Text = "Computer Science Course";
            // 
            // rbtn3rdYear
            // 
            this.rbtn3rdYear.AutoSize = true;
            this.rbtn3rdYear.Location = new System.Drawing.Point(574, 180);
            this.rbtn3rdYear.Name = "rbtn3rdYear";
            this.rbtn3rdYear.Size = new System.Drawing.Size(79, 20);
            this.rbtn3rdYear.TabIndex = 9;
            this.rbtn3rdYear.TabStop = true;
            this.rbtn3rdYear.Text = "3rd Year";
            this.rbtn3rdYear.UseVisualStyleBackColor = true;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(278, 89);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(178, 22);
            this.txtFirstName.TabIndex = 10;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(278, 138);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(178, 22);
            this.txtLastName.TabIndex = 11;
            // 
            // grpModules
            // 
            this.grpModules.Controls.Add(this.chkDatabase);
            this.grpModules.Controls.Add(this.chkJava);
            this.grpModules.Controls.Add(this.chkVisualBasic);
            this.grpModules.Controls.Add(this.chkCPlus);
            this.grpModules.Controls.Add(this.chkCSharp);
            this.grpModules.Location = new System.Drawing.Point(483, 240);
            this.grpModules.Name = "grpModules";
            this.grpModules.Size = new System.Drawing.Size(238, 161);
            this.grpModules.TabIndex = 12;
            this.grpModules.TabStop = false;
            this.grpModules.Text = "Select Modules";
            // 
            // chkCSharp
            // 
            this.chkCSharp.AutoSize = true;
            this.chkCSharp.Location = new System.Drawing.Point(11, 21);
            this.chkCSharp.Name = "chkCSharp";
            this.chkCSharp.Size = new System.Drawing.Size(45, 20);
            this.chkCSharp.TabIndex = 0;
            this.chkCSharp.Text = "C#";
            this.chkCSharp.UseVisualStyleBackColor = true;
            // 
            // chkCPlus
            // 
            this.chkCPlus.AutoSize = true;
            this.chkCPlus.Location = new System.Drawing.Point(11, 47);
            this.chkCPlus.Name = "chkCPlus";
            this.chkCPlus.Size = new System.Drawing.Size(52, 20);
            this.chkCPlus.TabIndex = 1;
            this.chkCPlus.Text = "C++";
            this.chkCPlus.UseVisualStyleBackColor = true;
            // 
            // chkVisualBasic
            // 
            this.chkVisualBasic.AutoSize = true;
            this.chkVisualBasic.Location = new System.Drawing.Point(11, 73);
            this.chkVisualBasic.Name = "chkVisualBasic";
            this.chkVisualBasic.Size = new System.Drawing.Size(103, 20);
            this.chkVisualBasic.TabIndex = 2;
            this.chkVisualBasic.Text = "Visual Basic";
            this.chkVisualBasic.UseVisualStyleBackColor = true;
            // 
            // chkJava
            // 
            this.chkJava.AutoSize = true;
            this.chkJava.Location = new System.Drawing.Point(11, 99);
            this.chkJava.Name = "chkJava";
            this.chkJava.Size = new System.Drawing.Size(59, 20);
            this.chkJava.TabIndex = 3;
            this.chkJava.Text = "Java";
            this.chkJava.UseVisualStyleBackColor = true;
            // 
            // chkDatabase
            // 
            this.chkDatabase.AutoSize = true;
            this.chkDatabase.Location = new System.Drawing.Point(11, 125);
            this.chkDatabase.Name = "chkDatabase";
            this.chkDatabase.Size = new System.Drawing.Size(89, 20);
            this.chkDatabase.TabIndex = 4;
            this.chkDatabase.Text = "Database";
            this.chkDatabase.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1240, 519);
            this.Controls.Add(this.grpModules);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.rbtn3rdYear);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnTotalCost);
            this.Controls.Add(this.rbtn2ndYear);
            this.Controls.Add(this.rbtn1stYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Course";
            this.grpModules.ResumeLayout(false);
            this.grpModules.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rbtn1stYear;
        private System.Windows.Forms.RadioButton rbtn2ndYear;
        private System.Windows.Forms.Button btnTotalCost;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rbtn3rdYear;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.GroupBox grpModules;
        private System.Windows.Forms.CheckBox chkJava;
        private System.Windows.Forms.CheckBox chkVisualBasic;
        private System.Windows.Forms.CheckBox chkCPlus;
        private System.Windows.Forms.CheckBox chkCSharp;
        private System.Windows.Forms.CheckBox chkDatabase;
    }
}

