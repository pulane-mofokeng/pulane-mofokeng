﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prac6_Books36002887
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFirstName.Clear();
            txtLastName.Clear();

            rbtn1stYear.Checked = false;
            rbtn2ndYear.Checked = false;
            rbtn3rdYear.Checked = false;

            chkCSharp.Checked = false;
            chkCPlus.Checked = false;
            chkVisualBasic.Checked = false;
            chkJava.Checked = false;
            chkDatabase.Checked = false;

        }

        private void btnTotalCost_Click(object sender, EventArgs e)
        {
            // calculate
            try
            {
                const double PRICE_CSHARP = 550.67;
                const double PRICE_CPP = 530.30;
                const double PRICE_VISUALBASIC = 480.02;
                const double PRICE_JAVA = 756.60;
                const double PRICE_DATABASE = 736.45;

                //input validation
                if (string.IsNullOrEmpty(txtFirstName.Text) ||
                    string.IsNullOrEmpty(txtLastName.Text))
                {
                    MessageBox.Show("Please enter the First and Last Name");
                    return;
                }
                if (!(rbtn1stYear.Checked || rbtn2ndYear.Checked || rbtn3rdYear.Checked))
                {
                    MessageBox.Show("Please select your level of study");
                    return;
                }
                double total = 0;
                if (chkCSharp.Checked)
                    total += PRICE_CSHARP;

                if (chkCPlus.Checked)
                    total += PRICE_CPP;

                if (chkVisualBasic.Checked)
                    total += PRICE_VISUALBASIC;

                if (chkJava.Checked)
                    total += PRICE_JAVA;

                if (chkDatabase.Checked)
                    total += PRICE_DATABASE;

                //display results
                string year = "";
                if (rbtn1stYear.Checked) year = "1";
                if (rbtn2ndYear.Checked) year = "2";
                if (rbtn3rdYear.Checked) year = "3";

                string message = $"Hello {txtFirstName.Text} {txtLastName.Text}\n" +
                                 $"Year of study is level {year}\n" +
                                 $"Your Total Cost is R{total:F2}";

                MessageBox.Show(message);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
          
           
        }
    }
}
