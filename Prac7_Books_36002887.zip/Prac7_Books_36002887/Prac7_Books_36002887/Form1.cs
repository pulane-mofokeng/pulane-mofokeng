﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prac7_Books_36002887
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //close the application
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //clear the forms inputs
            txtTickets.Text = "";
            chkReturn.Checked = false;
            rbtnIkageng.Checked = false;
            rbtnPromosa.Checked = false;
            rbtnMohadin.Checked = false;
            
            
        }

        private void btnBookLift_Click(object sender, EventArgs e)
        {
            //Calculate the ticket fee
            if (!int.TryParse(txtTickets.Text.Trim() out int tickets) || tickets < 0)
                MessageBox.Show("Enter correct number of tickets");
            if (chkReturn.Checked)
            {
                MessageBox.Show("We will book you a return trip.If this box is checked you will receive a 20% Discount");
            }
            
            decimal basicFee;
            string pickupPoint;
            if (rbtnIkageng.Checked)
            {
                basicFee = 250.00m;
                pickupPoint = "Potch Ikageng";
            }

            else if (rbtnPromosa.Checked)
            {
                basicFee = 220.00m;
                pickupPoint = "Potch Promosa";
                
            }

            else if (rbtnMohadin.Checked)
            {
                basicFee = 270.00m;
                pickupPoint = "Potch Mohadin";
            }
            else
            {
                basicFee = 200.00m;
                pickupPoint = "Main Potch";
            }

            if (lstDestination.SelectedItem == null)
            {
                MessageBox.Show("Please choose a destination from the list");
                return;
            }
            string destination = lstDestination.SelectedItem.ToString();
            decimal additionalFee = 0m;

            switch (destination)
            {
                case "Johanessburg":
                    additionalFee = 200.00m;
                    break;
                case "Pretoria":
                    additionalFee = 250.00m;
                    break;
                case "Randfontein":
                    additionalFee = 150.00m;
                    break;
                case "Durban":
                    additionalFee = 700.00m;
                    break;
                case "Centurion":
                    additionalFee = 250.00m;
                    break;
                case "Bloemfontein":
                    additionalFee = 400.00m;
                    break;
                case "Capetown":
                    additionalFee = 900.00m;
                    break;
                default:
                    MessageBox.Show("Please select the destination from the list");
                    break;
            }
            decimal liftFare = basicFee * additionalFee;
            decimal totalFare = liftFare * tickets;

            if (chkReturn.Checked)
            {
                totalFare = totalFare * 0.8m * 2m;
            }
        }
    }
}
