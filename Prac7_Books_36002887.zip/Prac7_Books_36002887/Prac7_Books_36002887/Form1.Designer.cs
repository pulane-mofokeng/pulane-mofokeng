﻿namespace Prac7_Books_36002887
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBookLift = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTickets = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkReturn = new System.Windows.Forms.CheckBox();
            this.rbtnIkageng = new System.Windows.Forms.RadioButton();
            this.rbtnPromosa = new System.Windows.Forms.RadioButton();
            this.rbtnMohadin = new System.Windows.Forms.RadioButton();
            this.lstDestination = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBookLift
            // 
            this.btnBookLift.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBookLift.Location = new System.Drawing.Point(39, 467);
            this.btnBookLift.Name = "btnBookLift";
            this.btnBookLift.Size = new System.Drawing.Size(204, 45);
            this.btnBookLift.TabIndex = 0;
            this.btnBookLift.Text = "Book Lift";
            this.btnBookLift.UseVisualStyleBackColor = true;
            this.btnBookLift.Click += new System.EventHandler(this.btnBookLift_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 398);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "No. of Tickets:";
            // 
            // txtTickets
            // 
            this.txtTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTickets.Location = new System.Drawing.Point(114, 395);
            this.txtTickets.Name = "txtTickets";
            this.txtTickets.Size = new System.Drawing.Size(159, 22);
            this.txtTickets.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnMohadin);
            this.groupBox1.Controls.Add(this.rbtnPromosa);
            this.groupBox1.Controls.Add(this.rbtnIkageng);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 129);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Potchefstroom Pickup points";
            // 
            // chkReturn
            // 
            this.chkReturn.AutoSize = true;
            this.chkReturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReturn.Location = new System.Drawing.Point(19, 371);
            this.chkReturn.Name = "chkReturn";
            this.chkReturn.Size = new System.Drawing.Size(99, 20);
            this.chkReturn.TabIndex = 4;
            this.chkReturn.Text = "Return Trip?";
            this.chkReturn.UseVisualStyleBackColor = true;
            // 
            // rbtnIkageng
            // 
            this.rbtnIkageng.AutoSize = true;
            this.rbtnIkageng.Location = new System.Drawing.Point(3, 19);
            this.rbtnIkageng.Name = "rbtnIkageng";
            this.rbtnIkageng.Size = new System.Drawing.Size(135, 17);
            this.rbtnIkageng.TabIndex = 0;
            this.rbtnIkageng.TabStop = true;
            this.rbtnIkageng.Text = "Potchefstroom Ikageng";
            this.rbtnIkageng.UseVisualStyleBackColor = true;
            // 
            // rbtnPromosa
            // 
            this.rbtnPromosa.AutoSize = true;
            this.rbtnPromosa.Location = new System.Drawing.Point(3, 53);
            this.rbtnPromosa.Name = "rbtnPromosa";
            this.rbtnPromosa.Size = new System.Drawing.Size(137, 17);
            this.rbtnPromosa.TabIndex = 1;
            this.rbtnPromosa.TabStop = true;
            this.rbtnPromosa.Text = "Potchefstroom Promosa";
            this.rbtnPromosa.UseVisualStyleBackColor = true;
            // 
            // rbtnMohadin
            // 
            this.rbtnMohadin.AutoSize = true;
            this.rbtnMohadin.Location = new System.Drawing.Point(3, 90);
            this.rbtnMohadin.Name = "rbtnMohadin";
            this.rbtnMohadin.Size = new System.Drawing.Size(137, 17);
            this.rbtnMohadin.TabIndex = 2;
            this.rbtnMohadin.TabStop = true;
            this.rbtnMohadin.Text = "Potchefstroom Mohadin";
            this.rbtnMohadin.UseVisualStyleBackColor = true;
            // 
            // lstDestination
            // 
            this.lstDestination.FormattingEnabled = true;
            this.lstDestination.Items.AddRange(new object[] {
            "Johannesburg",
            "Pretoria",
            "Randfontein",
            "Durban",
            "Centurion",
            "Bloemfontein",
            "Capetown"});
            this.lstDestination.Location = new System.Drawing.Point(12, 172);
            this.lstDestination.Name = "lstDestination";
            this.lstDestination.Size = new System.Drawing.Size(200, 108);
            this.lstDestination.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Destination:";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(597, 467);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(155, 45);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(334, 467);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(154, 45);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 539);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstDestination);
            this.Controls.Add(this.chkReturn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtTickets);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBookLift);
            this.Name = "Form1";
            this.Text = "Abahambe Lifts";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBookLift;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTickets;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkReturn;
        private System.Windows.Forms.RadioButton rbtnMohadin;
        private System.Windows.Forms.RadioButton rbtnPromosa;
        private System.Windows.Forms.RadioButton rbtnIkageng;
        private System.Windows.Forms.ListBox lstDestination;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
    }
}

